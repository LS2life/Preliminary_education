package menuView3;

import java.util.ArrayList;

public class Menu {
		
	ArrayList<CoffeemenuDTO> list =new ArrayList<CoffeemenuDTO>();
	public ArrayList<CoffeemenuDTO> getMenu(){
		return list;
	}
}
	

