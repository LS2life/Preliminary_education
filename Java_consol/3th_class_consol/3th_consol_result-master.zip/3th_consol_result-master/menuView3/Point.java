package menuView3;

public class Point implements PointIO{
	@Override
	public double Point(double num) {
		return num *0.1;
	}
	
}
