package menuView2;

import java.util.Scanner;

import D14.Bank;

public class Orderbar extends Menu {
	public void menubar() {
		
	}
	Scanner sc = new Scanner(System.in);
	int menu = 0;
	int quantity = 0;// 수량
	int calculation;// 계산
	int card;// 카드
	int cash;// 현금
	double point = 0;

	public void member () {//맴버
		
		//메뉴선택
		Point m = new Point();
		do{
	System.out.println("메뉴 선택");
	menu = sc.nextInt();
	System.out.println("수량");
	quantity = sc.nextInt();
	// 총 금액
//	calculation = quantity * list.get(menu).getAmount();
//	System.out.println("총 금액 :" +"quantity * list.get(menu).getAmount()");
		}while (menu >= 0);
	
		//카드계산
		
		do {
			System.out.println("1.카드  2.현금"); //선택
			card = sc.nextInt();
			
		}while(card != 1);
		if(card != 2) {
				point = m.Point(card);
				System.out.println("계산되었습니다");
		//현금계산
				if(cash !=2) {
					
				System.out.println("입금액");
				cash = sc.nextInt();
				 System.out.println("거스름돈:" + (cash - calculation));
				 System.out.println("계산되었습니다");
				point = m.Point(calculation);
				}
		}
		}
}
