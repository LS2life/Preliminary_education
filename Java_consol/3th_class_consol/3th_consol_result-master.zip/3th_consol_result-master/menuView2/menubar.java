package menuView2;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.DefaultBoundedRangeModel;

public class menubar extends Menu {
	public void me() {
		CoffeemenuDTO c = new CoffeemenuDTO() ;
		c.setMenu("a");
		c.setKcal(1);
		c.setAmount(4000);
	}
}
