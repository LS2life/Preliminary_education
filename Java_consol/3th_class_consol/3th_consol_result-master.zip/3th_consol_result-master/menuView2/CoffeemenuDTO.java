package menuView2;

public class CoffeemenuDTO {
	private String menu;
	private int amount; //가격
	private int kcal;
	
	
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public int getKcal() {
		return kcal;
	}
	public void setKcal(int kcal) {
		this.kcal = kcal;
	}
	@Override
	public String toString() {
		return "Coffeemenu[menu="+menu + "kcal=" +kcal +",amount="+amount+"]";
	}
}
	
	

	