package menuView2;

public interface PointIO {
	
	double Point(double num);
	
}
