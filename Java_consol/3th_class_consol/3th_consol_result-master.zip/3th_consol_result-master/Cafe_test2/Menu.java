package Cafe_test2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Menu {
	public int getMenu() {
		Scanner sc = new Scanner(System.in);
		int number;
		do {
			System.out.println("[�޴�]");
			System.out.println("1. ȸ������");
			System.out.println("2. �α���");
			System.out.println("3. ȸ����ȸ");
			System.out.println("4. ����");
			System.out.print("���� : ");
			number = sc.nextInt();

			try {
				number = sc.nextInt();
				sc.nextLine();
			} catch (InputMismatchException e) {
				sc.nextLine();
				System.out.println("�߸��� �Է�");
			}
			return number;
		} while (number >= 1 && number <= 4);
	}
}
