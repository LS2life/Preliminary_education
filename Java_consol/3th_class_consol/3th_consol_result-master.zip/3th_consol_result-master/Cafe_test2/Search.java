package Cafe_test2;

import java.util.ArrayList;

public class Search {
	//전부찾기
	public void allSearch(ArrayList<CafeDTO> memberList) {
		for (int i = 0; i < memberList.size(); i++) {
			System.out.println(memberList.get(i).getAge());
			System.out.println(memberList.get(i).getFd());
			System.out.println(memberList.get(i).getGrade());
			System.out.println(memberList.get(i).getId());
			System.out.println(memberList.get(i).getName());
			System.out.println(memberList.get(i).getPassword());
		}
	}
}
