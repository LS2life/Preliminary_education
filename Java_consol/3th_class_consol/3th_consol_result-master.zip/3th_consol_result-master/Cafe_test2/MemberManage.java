package Cafe_test2;

public class MemberManage {
	
}
