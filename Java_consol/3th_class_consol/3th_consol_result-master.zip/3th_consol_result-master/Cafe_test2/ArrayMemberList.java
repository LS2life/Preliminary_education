package Cafe_test2;

import java.util.ArrayList;

public class ArrayMemberList {
	// 파일에 넣을 배열 생성자 생성
	static ArrayList<CafeDTO> memberList = new ArrayList<CafeDTO>();

	public ArrayList<CafeDTO> getMemberList() {
		return memberList;
	}
}
