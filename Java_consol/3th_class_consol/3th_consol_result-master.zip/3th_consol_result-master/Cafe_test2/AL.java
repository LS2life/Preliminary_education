package Cafe_test2;

import java.util.ArrayList;

public interface AL {

	
}
