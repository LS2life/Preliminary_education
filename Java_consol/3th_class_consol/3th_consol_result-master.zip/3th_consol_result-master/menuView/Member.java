package menuView;

public interface Member {
	
	
	double Point(double num);
	
	
	
	
}
