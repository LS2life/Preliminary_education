package menuView;

public class asdf {
	public static void main(String[] args) {
		cafe c =new cafe();
		c.member();
	}
}
