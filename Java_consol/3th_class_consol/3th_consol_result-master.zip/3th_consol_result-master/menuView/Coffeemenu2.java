package menuView;

public class Coffeemenu2 {
	private String menu;
	private String amount;
	private String kcal;
	
	public String getMenu() {
		return menu;
	}
	public void setMenu(String menu) {
		this.menu = menu;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getKcal() {
		return kcal;
	}
	public void setKcal(String Kcal) {
		this.kcal = kcal;
	}
	@Override
	public String toString() {
		return "Coffeemenu[menu="+menu + "kcal=" +kcal +",amount="+amount+"]";
	}
}
	
	

	