package menuView;

public class member1 implements Member{
	@Override
	public double Point(double num) {
		return num *0.1;
	}
	
}
