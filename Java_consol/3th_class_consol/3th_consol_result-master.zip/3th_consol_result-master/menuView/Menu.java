package menuView;

import java.util.ArrayList;

public class Menu {
		
	ArrayList<Coffeemenu> list =new ArrayList<Coffeemenu>();
	public ArrayList<Coffeemenu> getMenu(){
		return list;
	}
}
	

