package menuView;

import java.util.Scanner;

public class cafe extends Menu {
	
	Scanner sc = new Scanner(System.in);
	int menu = 0;
	int quantity;// 수량
	int calculation;// 계산
	int card;// 카드
	int cash;// 현금
	int order = 0;// 주문
	double point = 0;

	public void member() {
		member1 m = new member1();
		while (menu != 0) {

			System.out.println("메뉴선택");
			menu = sc.nextInt();
			System.out.println("수량");
			quantity = sc.nextInt();
			calculation += list.get(menu).getAmount() * quantity;
		}
		System.out.println("1.카드로 계산하시겠습니까 2.현금으로 게산하시겠습니까");
		card = sc.nextInt();
		while (card == 0) {
			if (card != 0) {
				System.out.println("계산되었습니다");
				point = m.Point(calculation);
				if (order == 0) {

					System.out.println("추가주문하시겠습니까 1번 yes 2번 no");
					order = sc.nextInt();
					return;
				}
			}
			if (cash != 0) {

				System.out.println("현금계산");
				cash = sc.nextInt();
				System.out.println(cash - menu * quantity);
				System.out.println("계산되었습니다.");
				if (order == 2) {
					System.out.println("추가주문하시겠습니까 1번 yes 2번 no");
					order = sc.nextInt();
					return;
				}
			}
			point = m.Point(calculation);
		}

		System.out.println("Point : " + point);

		list.get(menu).getAmount();
	}

	public void guest() {
		while (menu != -1) {
			System.out.println("메뉴선택");
			menu = sc.nextInt();

			System.out.println("수량");
			quantity = sc.nextInt();

			calculation += quantity * list.get(menu).getAmount();
		}
		System.out.println("카드로 계산하시겠습니까 1번,현금으로 게산하시겠습니까. 2번");
		card = sc.nextInt();
		while (card == 0) {
			if (card != 0) {
				System.out.println("계산되었습니다");
				if (order == 2) {
					System.out.println("추가주문하시겠습니까 1번 yes 2번 no");
					order = sc.nextInt();
					return;
				}
			}
		}
		if (cash != 0) {

			System.out.println("현금계산");
			cash = sc.nextInt();
			System.out.println(cash - menu * quantity);
			System.out.println("계산되었습니다.");
			if (order == 2) {
				System.out.println("추가주문 하시겠습니까 1번yes 2번 no");
				order = sc.nextInt();
				return;
			}
		}
	}
	
}
