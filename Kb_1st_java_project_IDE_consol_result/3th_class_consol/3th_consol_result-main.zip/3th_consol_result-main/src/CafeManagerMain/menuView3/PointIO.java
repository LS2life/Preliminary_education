package menuView3;

public interface PointIO {
	
	double Point(double num);
	
}
