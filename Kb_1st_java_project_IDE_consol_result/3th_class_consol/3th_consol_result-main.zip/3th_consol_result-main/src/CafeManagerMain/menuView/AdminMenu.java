package menuView;

public class AdminMenu {
}
