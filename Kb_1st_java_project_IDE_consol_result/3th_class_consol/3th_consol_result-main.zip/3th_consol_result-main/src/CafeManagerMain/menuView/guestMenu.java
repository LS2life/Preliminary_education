package menuView;

public class guestMenu {
}
