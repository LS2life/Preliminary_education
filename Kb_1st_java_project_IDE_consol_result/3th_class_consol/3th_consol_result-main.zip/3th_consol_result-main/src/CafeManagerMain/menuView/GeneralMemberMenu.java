package menuView;

public class GeneralMemberMenu {
}
