package controller;

import menuView.MenuView;
import orderMenuView.CafeMenubar;
import service.CafeManagerIO;
import service.CafeMenuIO;
import service.Join;
import service.Login;

import java.io.IOException;

public class CafeManagerController2 {
    private MenuView crp = new MenuView();
    private CafeMenubar cmb = new CafeMenubar();
    private Join join = new Join();
    private Login anlogin= new Login();
    private CafeManagerIO cafeio = new CafeManagerIO();
    private CafeMenuIO cafeMenuIo = new CafeMenuIO();

    public void runApp() throws IOException {
        int choice1 = 0;
        int choice2 = 0;
        int choice3 = 0;
        boolean exit = true;
        cafeio.readReader();
        cafeMenuIo.readReader();

        while (exit) {
            choice1 = crp.firstViewManu();
                if(choice1 == 0) {
                    exit = false;
                }

            switch (choice1) {
                case 0:
                    break;

                case 1: //로그인
                    choice1 = anlogin.login();
                    break;

                case 2: //회원가입
                    choice1 = join.regist();
                    break;

                case 3: // 비회원 주문
                    //TODO 비회원 주문 Part.손재현
                    break;
            }

            // super user login
            switch (choice1) {
                case 0:
                    break;

                case 1:  // 회원정보관리
                    choice2 = crp.infoMenu();

                    // 회원정보관리 메뉴
                    switch (choice2) {
                        case 0: // 이전단계
                            break;

                        case 1:// 서브메니저 변경
                            choice2 = crp.managerChange();
                            break;

                        case 2: // 리워드 포인트 변경
                            choice2 = crp.reWards();
                            break;

                        case 3: // 회원 특기사항 메모
                            choice2 = crp.memgerMemo();

                            break;
                        case 4: // 회원 정보 삭제
                            choice2 = crp.deleteMember();

                            break;
                    }
                    break;

                case 2: // 메뉴수정
                    choice2 = crp.teaAndDessertMenu();
                    // TODO 메뉴 수정 추가.
                    // 메뉴 관리
                    switch (choice2) {
                        case 0:
                            break;

                        case 1:  //메뉴수정1 음료

                            break;
                        case 2: // 메뉴수정2 디저트

                            break;

                    }
                    break;

                case 3: // 메뉴 주문
                    choice2 = cmb.orderMainMenu();
                    if (choice2 == 0){
                        choice1 = 0;
                        choice2 = 0;
                        exit = false;

                    }else if(choice2 == 1) {
                        cmb.choiceTea();
                        cmb.additionalOrders();
                        cmb.payment();

                    }else if (choice2 == 2) {
                        cmb.choiceDessert();
                        cmb.additionalOrders();
                        cmb.payment();

                    }else if(choice2 == 3) {
                        choice1 = 0;
                        choice2 = 0;

                    }else {
                        System.out.println("메뉴를 선택해주세요");
                    }
                    switch (choice3) {
                        case 0:
                            break;
                        case 1:
                            cmb.card();
                        case 2:
                            choice3 = cmb.cash();
                            if(choice3 == 1) {
                                cmb.useRewardsPoint();
                                cmb.changeCash();

                            }else if (choice3 == 2){

                            }
                    }

            }
        }
        System.out.println("이용해주셔서 감사합니다.");
    }
}