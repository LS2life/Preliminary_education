package orderMenuView;

import java.util.InputMismatchException;
import java.util.Scanner;

public class CafeMenubar {
    Scanner sc = new Scanner(System.in);
    int choice = -1;

    // 메뉴 주문 첫 화면
    public int orderMainMenu() {
        while (choice == -1) {
            try {
                System.out.println("  < 메뉴 >");
                //Todo 메뉴판 출력
                System.out.println("1. 음료 선택");
                System.out.println("2. 디저트 선택");
                System.out.println("3. 메인메뉴");
                System.out.println("0. 종료");
                System.out.print("선택 : ");
                choice = sc.nextInt();
                sc.nextLine();

            } catch (InputMismatchException | NullPointerException e) {
                sc.nextLine();
                e.printStackTrace();
                System.out.println("잘못 누르셨습니다.");
                sc.nextLine();
            }
        }
        return choice;
    }

    // 음료 선택
    public int choiceTea() {
        while (choice == -1) {
            try {
                //todo 음료 메뉴 출력
                System.out.println("메뉴번호를 선택해주세요.");
                System.out.print("선택 : ");
                choice = sc.nextInt();
                sc.nextLine();

            } catch (InputMismatchException e) {
                e.printStackTrace();
                sc.nextLine();
                System.out.println("메뉴번호를 선택해주세요.");

            }
        }
        return choice;
    }

    // 디저트 선택
    public int choiceDessert() {
        while (choice == -1) {
            try {

                //todo 디저트 메뉴 출력
                System.out.println("메뉴번호를 선택해주세요.");
                System.out.print("선택 : ");
                choice = sc.nextInt();
                sc.nextLine();
            } catch (InputMismatchException e) {
                e.printStackTrace();
                sc.nextLine();
                System.out.println("메뉴번호를 선택해주세요.");
            }
        }
        return choice;
    }

    // 추가주문
    public int additionalOrders() {
        while (choice == -1) {
            try {
                System.out.println("추가주문 하시겠습니까?");
                System.out.println("1. 음료");
                System.out.println("2. 디저트");
                System.out.println("3. 결제");
                System.out.println("0. 종료");
                System.out.print("선택 : ");
                choice = sc.nextInt();
                sc.nextLine();

            } catch (InputMismatchException e) {
                e.printStackTrace();
                sc.nextLine();
                System.out.println("메뉴번호를 선택해주세요.");
            }
        }
        return choice;
    }

    // 결제방법 선택
    public int payment() {
        while (choice == -1) {
            try {
                //Todo 구매금액 및 호원은 리워드 포인트 출력
                System.out.println("1. 카드");
                System.out.println("2. 현금");
                System.out.print("선택 : ");
                choice = sc.nextInt();
                sc.nextLine();

            } catch (InputMismatchException e) {
                e.printStackTrace();
                sc.nextLine();
                System.out.println("메뉴번호를 선택해주세요.");
            }
        }
        return choice;
    }

    // 현금 결제 및 리워드 포인트 사용
    public int cash() {
        while (choice == -1) {
            try {
                System.out.println("리워드 포인트를 사용하시겠습니까?");
                System.out.println("1. 포인트 사용");
                System.out.println("2. 현금결제");
                System.out.print("선택 : ");
                choice = sc.nextInt();
                sc.nextLine();

            } catch (InputMismatchException e) {
                e.printStackTrace();
                sc.nextLine();
                System.out.println("메뉴번호를 선택해주세요.");
            }
        }
        return choice;
    }

    //리워드 포인트 사용
    public int useRewardsPoint() {
        try {
            System.out.println("사용하실 포인트를 입력해주세요.");
            System.out.print("포인트 : ");
            choice = sc.nextInt();
            sc.nextLine();
            //todo 포인트 반영

        } catch (InputMismatchException e) {
            e.printStackTrace();
            sc.nextLine();
        }
        return 0;
    }

    // 현금 투입 및 거스름돈 반환
    public int changeCash () {
        try {
            System.out.println("투입구로 현금을 넣어주세요.");
            System.out.print("금액 : ");
            choice = sc.nextInt();
            sc.nextLine();

            System.out.println("현금계산 잔액은 " + getAmount + "입니다.");
            System.out.println("남은 포인트는 " + RewardPoint() + "입니다.");
            System.out.println("결제가 완료되었습니다.");
            System.out.println("이용해 주셔서 감사합니다.");

        } catch (InputMismatchException e) {
            e.printStackTrace();
            sc.nextLine();
            System.out.println("금액을 투입해주세요.");
        }
        return choice;
    }

    // 카드 결제
    public void card () {
        System.out.println("신용카드 결제");
        System.out.println("결제 중입니다.");
        //todo 딜레이 5초
        System.out.println("결제가 완료 되었습니다.");
        System.out.println("이용해 주셔서 감사합니다.");
    }
}