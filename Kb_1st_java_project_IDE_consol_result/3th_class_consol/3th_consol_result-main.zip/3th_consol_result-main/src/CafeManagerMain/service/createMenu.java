package service;

import dto.CafeManagerDTO;
import dto.CafeMenuDTO;

import java.io.FileWriter;
import java.util.Scanner;

public class createMenu extends CafeMenuIO {

	CafeMenuIO cmni = new CafeMenuIO();

	public CafeMenuIO getCafeMenuIO() {
		return getCafeMenuIO();
	}

	Scanner sc = new Scanner(System.in);
	final String only_number = "[0-9]+";

	//회원 가입
	public int createTeaBack()  {
		CafeMenuDTO cmudto = new CafeMenuDTO();

		int menuNumber;
		boolean tf = true;

		do {
			System.out.println("\n메뉴판을 재구성합니다.");
			System.out.println("원하시는 메뉴번호를 입력해 주세요");
			System.out.print("메뉴번호 : ");
			menuNumber = sc.nextInt();
			for (int i = 0; i < CafeArrayList.menuList.size(); i++) {
				if (menuNumber == CafeArrayList.menuList.get(i).getNo()) {
					tf = false;
					System.out.println("중복된 번호가 있습니다.\n");
					break;
				} else {
					tf = true;
				}

			}
		} while (tf == false);
		if (tf == true) {
			cmudto.setNo(menuNumber);
		}

		System.out.println("생성할 메뉴명을 입력해주세요.");
		System.out.print("메뉴 : ");
		cmudto.setMenu(sc.nextLine());

		System.out.println("칼로리를 입력해주세요.");
		System.out.print("kcal/glass : ");
		cmudto.setKcal(sc.nextInt());
		sc.nextLine();

		System.out.println("금액을 입력해주세요.");
		System.out.print("kcal/glass : ");
		cmudto.setPrice(sc.nextInt());
		sc.nextLine();


		// 성공적인 회원가입 시
		System.out.println("\n메뉴 변경이 완료 되었습니다.");
		System.out.println("회원정보 관리 화면으로 돌아갑니다.");
		System.out.println("-----------------------\n");

		// 임시 데이터 추가
		CafeArrayList.menuList.add(cmudto);

//		// 파일에 데이터 추가
//		cafeIO.writeFile(service.ArrayMemberList.menuList);

//		// 임시 데이터 삭제
//		service.ArrayMemberList.menuList.remove(0);

		// 덮어쓰기
		try (FileWriter menufw = new FileWriter(menuFile)) {
			// 저장할 정보들
			for (int i = 0; i < menuList.size(); i++) {
				String writeML = menuList.get(i).getNo() + "," + menuList.get(i).getMenu() + ","
						+ menuList.get(i).getName() + "," + menuList.get(i).getBirthday() + ","
						+ menuList.get(i).getPhone() + "," + menuList.get(i).getRewardsPoint() + ","
						+ menuList.get(i).getGrade() + "," + menuList.get(i).getDateOfJoin() + "\n";

				// 파일로 출력
				directfw.write(writeML);
				directfw.flush();
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return -1;
	}
}






		// 이 구간은 언젠가 꼭 없애야 하는 구간
//		do { 					//3   			//2			//1
//			System.out.print("등급[일반 - 0 | 부매니저 - 1 | 사장 - 2] : ");
//			grade = sc.nextLine();
//			cafeDTO.setGrade(grade);
//
//		} while (!grade.equals("0") || !grade.equals("1") || !grade.equals("2"));
		// 구간 - 여기까지

