package service;

import java.io.FileWriter;
import java.util.Objects;
import java.util.Scanner;
import dto.CafeManagerDTO;

public class Login extends CafeManagerIO {
	CafeManagerDTO cafedto = new CafeManagerDTO();
	Scanner sc = new Scanner(System.in);
	int ididx = 0;
	int gradeidx;

	// 로그인
	public int login() throws NumberFormatException{
		String loginId = "";
		String loginPw = "";

		// 일치 시 - true / 불일치 시 - false
		boolean id_pass = false;
		boolean pw_pass = false;

//		// 배열 작동 확인
//		try {
//			System.out.println(ArrayMemberList.memberList.size());
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		do {
			System.out.print("아이디 : ");
			loginId = sc.nextLine();
			if(Objects.equals(CafeManagerDTO.getSuperUser(), loginId)) {
				id_pass = true;
				System.out.println("\nSuper User Login");
				break;
			}else {

				for (int i = 0; i < CafeArrayList.memberList.size(); i++) {
					// System.out.println("for 진입");
					if (loginId.equals(CafeArrayList.memberList.get(i).getId())) {
						id_pass = true;
						System.out.println("아이디 성공");
						ididx = i;
						break;
					}
				}

				if (id_pass == false) {
					System.out.println("없는 아이디 입니다.");
					System.out.println("메인으로 돌아가시려면 0번을 입력해주세요.");
					System.out.print("0. 메인메뉴 : ");
					int choice = sc.nextInt();
					sc.nextLine();

					if (choice == 0) {
						gradeidx = -1;
						return gradeidx;
					} else {
						break;
					}
				}
			}
		} while (id_pass == false);

		do {
			try {
				System.out.print("비밀번호 : ");
				loginPw = sc.nextLine();
				if (Objects.equals(CafeManagerDTO.getSuperPass(),loginPw)) {
					gradeidx = 1;
					pw_pass = true;
				}else {
					for (int i = 0; i < CafeArrayList.memberList.size(); i++) {
						if (loginPw.equals(CafeArrayList.memberList.get(i).getPassword()) && (i == ididx)) {
							pw_pass = true;
							gradeidx = CafeArrayList.memberList.get(i).getGrade();
							System.out.println("등급 : " + gradeidx);
							if (gradeidx == 2) {
								gradeidx = 3;
							} else {
								gradeidx = 2;
							}
							break;
						}
					}
				}
			} catch (NumberFormatException e) {

			}
			if (pw_pass == false) {
				System.out.println("비밀번호가 틀렸습니다.");
			}
		} while (pw_pass == false);

		System.out.println("로그인 성공\n");
		return gradeidx;
	}


	// 조회
	public String search() {
		// 개인조회
		String search_id = "";
		boolean search_pass = false;
		String memberName = null;
		System.out.print("ID 검색 : ");
		search_id = sc.nextLine();

		for (int i = 0; i < CafeArrayList.memberList.size(); i++) {
			if (search_id.equals(CafeArrayList.memberList.get(i).getId())) {
				System.out.println("\n < " + CafeArrayList.memberList.get(i).getId() + " >");
				System.out.println("이름 : " + CafeArrayList.memberList.get(i).getName());
				System.out.println("생년월일 : " + CafeArrayList.memberList.get(i).getBirthday());
				System.out.println("전화번호 : " + CafeArrayList.memberList.get(i).getPhone());
				System.out.println("등급 : " + CafeArrayList.memberList.get(i).getGrade());
				search_pass = true;

			}
		}
		if (search_pass == false) {
			System.out.println("ID를 찾을 수 없습니다.\n");
		}
		return search_id;
	}

	public int subManagerList() {
		// 서브메니저 리스트 출력.
		if (CafeArrayList.memberList.size() != 0) {
			System.out.println("지정된 매니저가 없습니다.");
		} else {
			for (int i = 0; i < CafeArrayList.memberList.size(); i++) {
				if (Objects.equals(true, CafeArrayList.memberList.get(i).getAdmin())) {
					System.out.println("ID : " + CafeArrayList.memberList.get(i).getId());
					System.out.println("이름 : " + CafeArrayList.memberList.get(i).getName());
					System.out.println("생년월일 : " + CafeArrayList.memberList.get(i).getBirthday());
					System.out.println("등급 : " + CafeArrayList.memberList.get(i).getGrade());
					System.out.println("가입일 : " + CafeArrayList.memberList.get(i).getDateOfJoin());

				} else {
					System.out.println("지정된 매니저가 없습니다.");
				}
			}

		}
		return CafeArrayList.memberList.size();
	}
	// 삭제
	public void Delete() {
		String deletePw = "";

		System.out.print("비밀번호를 입력하세요 : ");
		deletePw = sc.nextLine();

		if (deletePw.equals(CafeArrayList.memberList.get(ididx).getPassword())) {
			CafeArrayList.memberList.remove(ididx);

			// 덮어쓰기
			try (FileWriter directfw = new FileWriter(directFile)) {
				// 저장할 정보들
				for (int i = 0; i < memberList.size(); i++) {
					String writeML = memberList.get(i).getId() + "," + memberList.get(i).getPassword() + ","
							+ memberList.get(i).getName() + "," + memberList.get(i).getBirthday() + ","
							+ memberList.get(i).getPhone() + "," + memberList.get(i).getGrade() + "\n";

					// 파일로 출력
					directfw.write(writeML);
					directfw.flush();
				}
			} catch (Exception e) {
				e.getMessage();
			}

			System.out.println("탈퇴 완료");
		}

		else {
			System.out.println("비밀번호가 틀렸습니다");
		}
	}

	// 변경
	public int Update() {
//		int choice;
//		String update_name, update_password;
//		int update_grade;
//
//		// 이름,비밀번호,등급 변경
//		do {
//			System.out.print("변경할 정보 선택[0 - 이름 / 1 - 비밀번호 / 2 - 등급] : ");
//			choice = sc.nextInt();
//			sc.nextLine();
//			if (choice < 0 || choice > 3) {
//				System.out.println("다시 입력해주세요");
//			}
//		} while (choice < 0 || choice > 3);
//
//		switch (choice) {
//		// 이름
//		case 0:
//			System.out.print("변경할" +
//					" 이름 : ");
//			update_name = sc.nextLine();
//
//			cafedto.setName(update_name);
//			cafedto.setBirthday(memberList.get(ididx).getBirthday());
//			cafedto.setDateOfJoin(memberList.get(ididx).getDateOfJoin());
//			cafedto.setId(memberList.get(ididx).getId());
//			cafedto.setPassword(memberList.get(ididx).getPassword());
//			cafedto.setGrade(memberList.get(ididx).getGrade());
//
//			memberList.set(ididx, cafedto);
//
//			// 덮어쓰기
//			try (FileWriter directfw = new FileWriter(directFile)) {
//				// 저장할 정보들
//				for (int i = 0; i < memberList.size(); i++) {
//					String writeML = memberList.get(i).getName() + "," + memberList.get(i).getBirthday() + ","
//							+ memberList.get(i).getDateOfJoin() + "," + memberList.get(i).getId() + ","
//							+ memberList.get(i).getPassword() + "," + memberList.get(i).getGrade() + "\n";
//
//					// 파일로 출력
//					directfw.write(writeML);
//					directfw.flush();
//				}
//			} catch (Exception e) {
//				e.getMessage();
//			}
//			break;
//
//		// 비밀번호
//		case 1:
//			System.out.print("변경할 비밀번호 : ");
//			update_password = sc.nextLine();
//
//			cafedto.setPassword(update_password);
//			cafedto.setBirthday(memberList.get(ididx).getBirthday());
//			cafedto.setDateOfJoin(memberList.get(ididx).getDateOfJoin());
//			cafedto.setId(memberList.get(ididx).getId());
//			cafedto.setName(memberList.get(ididx).getName());
//			cafedto.setGrade(memberList.get(ididx).getGrade());
//
//			memberList.set(ididx, cafedto);
//
//			// 덮어쓰기
//			try (FileWriter directfw = new FileWriter(directFile)) {
//				// 저장할 정보들
//				for (int i = 0; i < memberList.size(); i++) {
//					String writeML = memberList.get(i).getName() + "," + memberList.get(i).getBirthday() + ","
//							+ memberList.get(i).getDateOfJoin() + "," + memberList.get(i).getId() + ","
//							+ memberList.get(i).getPassword() + "," + memberList.get(i).getGrade() + "\n";
//
//					// 파일로 출력
//					directfw.write(writeML);
//					directfw.flush();
//				}
//			} catch (Exception e) {
//				e.getMessage();
//			}
//			break;
//
//		// 등급
//		case 2:
		int choice;
		int update_grade;
		String search_id = "";
		boolean search_pass = false;
		System.out.print("ID 검색 : ");
		search_id = sc.nextLine();

		for (int i = 0; i < CafeArrayList.memberList.size(); i++) {
			if (search_id.equals(CafeArrayList.memberList.get(i).getId())) {
				System.out.println("\n이름 : " + memberList.get(i).getName());
				System.out.println("생년월일 : " + CafeArrayList.memberList.get(i).getBirthday());
				System.out.println("전화번호 : " + CafeArrayList.memberList.get(i).getPhone());
				System.out.println("등급 : " + CafeArrayList.memberList.get(i).getGrade());
				search_pass = true;

			}
		}
		if (search_pass == false) {
			System.out.println("없는 이름 입니다");
		}

		do {
			System.out.println("회원 등급을 선택해주세요.");
			System.out.println("1. 매니저");
			System.out.println("2. 일반회원");
			System.out.print("등급 변경 : ");
			update_grade = sc.nextInt();
			sc.nextLine();
			if (update_grade == 1) {
				update_grade = 2;
			}else {
				update_grade = 3;
			}

		} while (update_grade == 2 || update_grade == 3);
		cafedto.setGrade(update_grade);
		cafedto.setBirthday(memberList.get(ididx).getBirthday());
		cafedto.setDateOfJoin(memberList.get(ididx).getDateOfJoin());
		cafedto.setId(memberList.get(ididx).getId());
		cafedto.setPassword(memberList.get(ididx).getPassword());
		cafedto.setName(memberList.get(ididx).getName());

		memberList.set(ididx, cafedto);
		choice = -1;

		// 덮어쓰기
		try (FileWriter directfw = new FileWriter(directFile)) {
			// 저장할 정보들
			for (int i = 0; i < memberList.size(); i++) {
				String writeML = memberList.get(i).getId() + "," + memberList.get(i).getPassword() + ","
						+ memberList.get(i).getName() + "," + memberList.get(i).getBirthday() + ","
						+ memberList.get(i).getGrade() + "," + memberList.get(i).getDateOfJoin() + "\n";

				// 파일로 출력
				directfw.write(writeML);
				directfw.flush();
			}
		} catch (Exception e) {
			e.getMessage();
		}
		return choice;
	}
}
