3th_class_consol_result  
=
*Cafe manager*
-   	 

With String member = " 이상수, 김여준, 손재현 ";


- Fortune Cookie 정도 Level로 만들면 될까? ? 
 
[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FLS2life%2F3th_consol_result&count_bg=%2357D35F&title_bg=%23FF5A00&icon=java.svg&icon_color=%23E7E7E7&title=Java&edge_flat=false)](https://hits.seeyoufarm.com)


```java
#include <stdio.h>
int main(void) {
    printf("Hello world! We are NEW!");
}
```


>###	PM 이상수	
>	<img src="https://img.shields.io/badge/JAVA-007396?style=for-the-badge&logo=java&logoColor=white">  
>	<img src="https://img.shields.io/badge/github-181717?style=for-the-badge&logo=github&logoColor=white">
>	<img src="https://img.shields.io/badge/Ubuntu-E95420?style=for-the-badge&logo=ubuntu&logoColor=black">
>	<img src="https://img.shields.io/badge/Intellij IDEA-EF2D5E?style=for-the-badge&logo=intellijidea&logoColor=black">
>	<img src="https://img.shields.io/badge/vim-019773?style=for-the-badge&logo=vim&logoColor=black">
>	<img src="https://img.shields.io/badge/Visual Studio Code-007ACC?style=for-the-badge&logo=visualstudiocode&logoColor=black">
>	<img src="https://img.shields.io/badge/Eclipse IDE-2C2255?style=for-the-badge&logo=eclipseide&logoColor=black">
>
>		's right. It's me E_San. I'm back to the NEW.
>-	의견	
>		1.	~~세계여행준비 원격관리  관심국가 지정, 해당국가 공항 위도경도~~ 복잡복잡 nono.  
>		2.	가계부 콘솔.  
> 		2.	학교 성적관리 관리자,학생.
>
> - Part. Algorithms, Planning, Interfaces, etc.

>###	김여준
>	<img src="https://img.shields.io/badge/JAVA-007396?style=for-the-badge&logo=java&logoColor=white">  
>	<img src="https://img.shields.io/badge/github-181717?style=for-the-badge&logo=github&logoColor=white">
>	<img src="https://img.shields.io/badge/Eclipse IDE-2C2255?style=for-the-badge&logo=eclipseide&logoColor=black">
>	
>		키보드 소리가 끊기질 않아. 현역지원군이었어?
>	- 의견  
>		- 피트니스 회원관리	- 로그인
>			- Comment. 이상수;
>				- 로그인,[관리자,회원 (종료?불필요? 회원이름,전화번호, 성별, 주민번호 앞자리)].	  
>				- 관리자모드 회원추가삭제 날짜별인바디 지문 및 카드 인식 초기화(재등록).	
>				- 회원별 인바디관리 (bmi지수 증감량 기간별 기록).	
>				- 월간 주간 인바디기준 다이어터 랭킹 - 회원 로그비중 높게 설정시.	
>				- 회원은 입장시 지문 또는 카드 인터페이스 생성.	
>				
>		- 카페 회원관리	-  로그인  
>			- Comment. 이상수;  
>				- 로그인 공통, 관리자 회원관리 공통.  
>				- 선호음료 리스트, 추가옵션 리스트.  
>				- 월별 주별 음료 소비량, 음료별 칼로리합산.  
>				- 음료당 리워드 10%등 현재포인트 확인.  
>				- 미리주문 기능, 선결제, 시간, 주문번호.
> 
> - Part. I/O Stream, DB  
            
>###	손재현
>	<img src="https://img.shields.io/badge/JAVA-007396?style=for-the-badge&logo=java&logoColor=white">  
>	<img src="https://img.shields.io/badge/github-181717?style=for-the-badge&logo=github&logoColor=white">
>	<img src="https://img.shields.io/badge/Eclipse IDE-2C2255?style=for-the-badge&logo=eclipseide&logoColor=black">
>	
>		아직 피가 끓는 나이지 그럼그럼.
>	- 의견  
>		- 의류 쇼핑몰 장바구니 개설
>		
>			- Comment. 이상수;  
>				- 안건구체화 필요.  
>				- 쇼핑 장바구니 정도.  
>				- 회원, 비회원, 관리자.  
>				- 상의, 하의, 신발, 악세서리, 세부목록 등등.
>                       	- 담은 목록 합산금액, 카테고리별 합산금액.  너무 빢쏀데?
>
> - Part. Manu View, Manu Algorithms, Payment
>                       	
